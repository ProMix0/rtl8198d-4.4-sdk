/*
 * Copyright (c) International Business Machines Corp., 2007
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See
 * the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * Author: Oliver Lohmann
 */

/*
 * Create a flashable NAND image from a binary image
 *
 * History:
 * 1.0 Initial release (tglx)
 * 1.1 Understands hex and dec input parameters (tglx)
 * 1.2 Generates separated OOB data, if needed. (oloh)
 * 1.3 Padds data/oob to a given size. (oloh)
 * 1.4 Removed argp because we want to use uClibc.
 * 1.5 Minor cleanup
 * 1.6 Written variable not initialized (-j did not work) (haver)
 * 1.7 Made NAND ECC layout configurable (haver)
 */

#include <unistd.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <getopt.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <math.h>

#include "error.h"
#include "config.h"
#include "nandecc.h"
#include "ecclayouts.h"

#define PROGRAM_VERSION "1.7"

#define ARRAY_SIZE(a)    (sizeof(a) / sizeof((a)[0]))

#define CHECK_ENDP(option, endp) do {			\
	if (*endp) {					\
		fprintf(stderr,				\
			"Parse error option \'%s\'. "	\
			"No correct numeric value.\n"	\
			, option);			\
		exit(EXIT_FAILURE);			\
	}						\
} while(0)

typedef enum action_t {
	ACT_NORMAL	    = 0x00000001,
} action_t;

#define PAGESIZE	2048
#define PADDING		   0 /* 0 means, do not adjust anything */
#define BUFSIZE		4096 /* size of buf for reading one page */

/* BCH8 define */
#define mm_max  15         	/* Dimension of Galoise Field */
#define nn_max  32768        	/* Length of codeword, n = 2**m - 1 */
#define tt_max  20          	/* Number of errors that can be corrected */
#define kk_max  32768        	/* Length of information bit, kk = nn - rr  */
#define rr_max  1000		/* Number of parity checks, rr = deg[g(x)] */
#define parallel_max  32	/* Number of parallel encoding/syndrome computations */
/* BCH8 define end */

/* BCH8 global variables */
int mm, nn, kk, tt, rr;		// BCH code parameters
int nn_shorten, kk_shorten;	// Shortened BCH code
int Parallel ;			// Parallel processing
int Verbose ;			// Mode indicator
int p[mm_max + 1], alpha_to[nn_max], index_of[nn_max] ;	// Galois field
int gg[rr_max] ;		// Generator polynomial
int T_G[rr_max][rr_max], T_G_R[rr_max][rr_max];		// Parallel lookahead table
int T_G_R_Temp[rr_max][rr_max] ; 
int data[kk_max], data_p[parallel_max][kk_max], recd[nn_max] ;	// Information data and received data

int bb[rr_max] ;		// Parity checks
int data_p_temp[parallel_max][kk_max]; 
int data_p_swap[parallel_max][kk_max];
/* BCH8 global variables end */

int pages = 1;

const char *ecc_layout = NULL;

static char doc[] = "\nVersion: " PROGRAM_VERSION "\n"
	"bin2nand - a tool for adding OOB information to a "
	"binary input file.\n";

static const char *optionsstr =
"  -c, --copyright          Print copyright informatoin.\n"
"  -j, --padding=<num>      Padding in Byte/Mi/ki. Default = no padding\n"
"  -l, --ecc-layout=<MTD,IBM,BCH8,BCH16> OOB placement scheme (default is IBM).\n"
"  -p, --pagesize=<num>     Pagesize in Byte/Mi/ki. Default = 2048\n"
"  -o, --output=<fname>     Output filename. Interleaved Data/OOB if\n"
"                           output-oob not specified.\n"
"  -q, --output-oob=<fname> Write OOB data in separate file.\n"
"  -?, --help               Give this help list\n"
"      --usage              Give a short usage message\n"
"  -V, --version            Print program version\n";

static const char *usage =
"Usage: bin2nand [-c?V] [-j <num>] [-p <num>] [-o <fname>] [-q <fname>]\n"
"            [--copyright] [--padding=<num>] [--pagesize=<num>]\n"
"            [--output=<fname>] [--output-oob=<fname>] [--help] [--usage]\n"
"            [--version]\n";

struct option long_options[] = {
	{ .name = "copyright", .has_arg = 0, .flag = NULL, .val = 'c' },
	{ .name = "padding", .has_arg = 1, .flag = NULL, .val = 'j' },
	{ .name = "pagesize", .has_arg = 1, .flag = NULL, .val = 'p' },
	{ .name = "output", .has_arg = 1, .flag = NULL, .val = 'o' },
	{ .name = "output-oob", .has_arg = 1, .flag = NULL, .val = 'q' },
	{ .name = "ecc-layout", .has_arg = 1, .flag = NULL, .val = 'l' },
	{ .name = "help", .has_arg = 0, .flag = NULL, .val = '?' },
	{ .name = "usage", .has_arg = 0, .flag = NULL, .val = 0 },
	{ .name = "version", .has_arg = 0, .flag = NULL, .val = 'V' },
	{ NULL, 0, NULL, 0}
};

#define __unused __attribute__((unused))
static const char copyright [] __unused = "Copyright IBM Corp. 2007";

struct args {
	action_t action;

	size_t pagesize;
	size_t oobsize;
	size_t padding;

	FILE* fp_in;
	const char *file_out_data; /* Either: Data and OOB interleaved
				      or plain data */
	const char *file_out_oob; /* OOB Data only. */
	struct nand_ecclayout *nand_oob;

	/* special stuff needed to get additional arguments */
	char *arg1;
	char **options;			/* [STRING...] */
};


static int ustrtoull(const char *cp, char **endp, unsigned int base)
{
	unsigned long long res = strtoull(cp, endp, base);

	switch (**endp) {
	case 'G':
		res *= 1024;
	case 'M':
		res *= 1024;
	case 'k':
	case 'K':
		res *= 1024;
	/* "Ki", "ki", "Mi" or "Gi" are to be used. */
		if ((*endp)[1] == 'i')
			(*endp) += 2;
	}
	return res;
}

static int
parse_opt(int argc, char **argv, struct args *args)
{
//	const char *ecc_layout = NULL;
	unsigned int i, oob_idx = 0;
	char* endp;

	while (1) {
		int key;

		key = getopt_long(argc, argv, "cj:l:p:o:q:?V", long_options, NULL);
		if (key == -1)
			break;

		switch (key) {
		case 'p': /* pagesize */
			args->pagesize = (size_t)
				ustrtoull(optarg, &endp, 0);
			CHECK_ENDP("p", endp);
			break;
		case 'j': /* padding */
			args->padding = (size_t)
				ustrtoull(optarg, &endp, 0);
			CHECK_ENDP("j", endp);
			break;
		case 'o': /* output */
			args->file_out_data = optarg;
			break;
		case 'q': /* output oob */
			args->file_out_oob = optarg;
			break;
		case 'l': /* --ecc-layout=<...> */
			ecc_layout = optarg;
			break;
		case '?': /* help */
			printf("%s%s", doc, optionsstr);
			exit(0);
			break;
		case 'V':
			printf("%s\n", PROGRAM_VERSION);
			exit(0);
			break;
		case 'c':
			printf("%s\n", copyright);
			exit(0);
		default:
			printf("%s", usage);
			exit(-1);
		}
	}

	if (optind < argc) {
		args->fp_in = fopen(argv[optind++], "rb");
		if ((args->fp_in) == NULL) {
			err_quit("Cannot open file %s for input\n",
				 argv[optind++]);
		}
	}

	switch (args->pagesize) {
	case 512:  args->oobsize = 16; oob_idx = 0; break;
	case 2048: args->oobsize = 64; oob_idx = 1; break;
	case 4096: args->oobsize =224; oob_idx = 1; break;
	default:
		err_msg("Unsupported page size: %d\n", args->pagesize);
		return -EINVAL;
	}

	/* Figure out correct oob layout if it differs from default */
	if (ecc_layout) {
		for (i = 0; i < ARRAY_SIZE(oob_placement); i++)
			if (strcmp(ecc_layout, oob_placement[i].name) == 0)
				args->nand_oob =
					oob_placement[i].nand_oob[oob_idx];
	}
	return 0;
}

static int
process_page(struct args *args, uint8_t *buf, FILE *fp_data, FILE *fp_oob,
	     size_t *written)
{
	int eccpoi;
	size_t i;
	uint8_t oobbuf[64];
	uint8_t ecc_code[3] = { 0, }; /* temp */

	/* Calculate ECC for each subpage of 256 bytes */
	memset(oobbuf, 0xff, sizeof(oobbuf));
	for (eccpoi = 0, i = 0; i < args->pagesize; i += 256, eccpoi += 3) {
		int j;
		nand_calculate_ecc(&buf[i], ecc_code);
		for (j = 0; j < 3; j++)
			oobbuf[args->nand_oob->eccpos[eccpoi + j]] = ecc_code[j];
	}

	/* write data */
	*written += fwrite(buf, 1, args->pagesize, fp_data);

	/* either separate oob or interleave with data */
	if (fp_oob) {
		i = fwrite(oobbuf, 1, args->oobsize, fp_oob);
		if (ferror(fp_oob)) {
			err_msg("IO error\n");
			return -EIO;
		}
	}
	else {
		i = fwrite(oobbuf, 1, args->oobsize, fp_data);
		if (ferror(fp_data)) {
			err_msg("IO error\n");
			return -EIO;
		}
	}

	return 0;
}

void parallel_encode_bch()   
/* Parallel computation of n - k parity check bits.  
 * Use lookahead matrix T_G_R.  
 * The incoming streams are fed into registers from the right hand  
 */   
{   int i, j, iii, Temp, bb_temp[rr_max] ;   
    int loop_count ;   
       
    // Determine the number of loops required for parallelism.     
    loop_count = ceil(kk_shorten / (double)Parallel) ;     
       
    // Serial to parallel data conversion   
    for (i = 0; i < Parallel; i++)   
    {   for (j = 0; j < loop_count; j++)   
        {   if (i + j * Parallel < kk_shorten)   
                data_p[i][j] = data[i + j * Parallel];   
            else   
                data_p[i][j] = 0;   
        }   
    }   
    
    // -----------------------------------------------------------------
    // Swap data around to match C-code vs. DUT
    // Note: only works for Parallel = 8
    // begin
    // -----------------------------------------------------------------

    for (j = 0; j < loop_count; j++)
      {
	for (i = 0; i < Parallel; i++)
        { data_p_temp[i][j] = data_p[i][j] ;
        }
      }

    for (j = 0; j < loop_count; j++)
      {
	for (i = 0; i < Parallel; i++)
	  {
	    data_p_swap[Parallel - 1 - i][j] = data_p_temp[i][j] ;
	  }
      }

    for (j = 0; j < loop_count; j=j+2)
      {
        for (i = 0; i < Parallel; i++)
          {
            data_p[i][j] = data_p_swap[i][j+1] ;
          }
      }
    for (j = 1; j < loop_count; j=j+2)
      {
        for (i = 0; i < Parallel; i++)
          {
            data_p[i][j] = data_p_swap[i][j-1] ;
          }
      }

    /***
    // just for display
    for (j = 0; j < loop_count; j++)
      { fprintf(stdout, "loop j = %d, ",j);
      for (i = 0; i < Parallel; i++)
        { fprintf(stdout, "%d", data_p[i][j]) ;
        }
	fprintf(stdout, "\n") ;
      }
    ***/

    // -----------------------------------------------------------------
    // Swap data around to match C-code vs. DUT
    // end
    // -----------------------------------------------------------------


    // Initialize the parity bits.   
    for (i = 0; i < rr; i++)   
        bb[i] = 0;   
       
    // Compute parity checks   
    // S(t) = T_G_R [ S(t-1) + M(t) ]   
    // Ref: Parallel CRC, Shieh, 2001   

    // Feed in data from beginning instead of end 
    // to match C-code vs. DUT
    // ORIGINAL: for (iii = loop_count - 1; iii >= 0; iii--)   

    for (iii = 0; iii <= loop_count - 1; iii++)
    {   for (i = 0; i < rr; i++)   
            bb_temp[i] = bb[i] ;   
        for (i = Parallel - 1; i >= 0; i--)   
            bb_temp[rr - Parallel + i] = bb_temp[rr - Parallel + i] ^ data_p[i][iii];   
           
        for (i = 0; i < rr; i++)   
        {   Temp = 0;   
            for (j = 0; j < rr; j++)   
                Temp = Temp ^ (bb_temp[j] * T_G_R[i][j]);   
            bb[i] = Temp;   
        }   
    }   
       
}   

char inttohex(int i)
// Convert Integer number to HEX
{	char r;
	if (i > 9)
		r = (char)(55 + i);
	else
		r = (char)(48 + i);
	return r;
}

void print_hex(int length, int Binary_data[length], FILE *std)
// Print the binary data in HEX form
// 1100 1010 = 5 3
{	int i, j, l, v;
	l = ceil((double)length / 4);
	
	for (j = l - 1; j >= 0; j--) 
	{	v = 0;
		for(i = 3; i >= 0; i--)
			v = v + (int)Binary_data[j * 4 + i] * (int)pow(2, i);
		fprintf(std, " %c", inttohex(v));
	}
}

void print_hex_low(int length, int Binary_data[length], FILE *std)
// Print the binary data in HEX form from low to high order
// 1100 1010 = C A
{	int i, j, l, v;
	l = ceil((double)length / 4);
	
	for (j = 0; j < l; j++) 
	{	v = 0;
		for(i = 0; i <= 3; i++)
			v = v + (int)Binary_data[j * 4 + i] * (int)pow(2, 3-i);
		fprintf(std, "%c", inttohex(v));
	}
}

static int
process_page_bch8(struct args *args, uint8_t *buf, FILE *fp_data, FILE *fp_oob,
	     size_t *written)
{
	int eccpoi;
	int i, j, k, l, m, n, p, in_count, in_codeword;
	uint8_t oobbuf[64];
	uint8_t ecc_code[13] = { 0, }; /* temp */
	int empty;
	
	/* convert data to data[] in binary format, 512 * 8 = 4096 */
	in_count = 0;
	in_codeword = 0;
	empty = 1;
	memset(oobbuf, 0xff, sizeof(oobbuf));
	
	for (i=0; i < args->pagesize; i++){
		if (buf[i] != 255){
			empty = 0;
			break;
		}
	}
	if (!empty){		
		for (eccpoi = 0, i = 0; i < args->pagesize; i += 512, eccpoi += 13) {
			in_count = 0;
			in_codeword = 0;
			for (p = 0; p < 512; p += 1){
				for(j = 7; j >= 0; j--){
					if (((int)pow(2,j)) & (buf[p + i]))
						data[in_count] = 1;
					else
						data[in_count] = 0;
					in_count++;
				}
			}
			
			parallel_encode_bch();
			
			l = ceil((double)rr / 8);
		
			for (j = 0; j < l; j++) 
			{	m = 0;
				for(n = 7; n >= 0; n--){
					m = m + (int)bb[j * 8 + n] * (int)pow(2, n);
				}
				oobbuf[args->nand_oob->eccpos[eccpoi + j]] = m;
			}		
		}
		oobbuf[11] = 0;
	}
	/* write data */
	*written += fwrite(buf, 1, args->pagesize, fp_data);

	/* write oob interleave with data */
	i = fwrite(oobbuf, 1, args->oobsize, fp_data);
	memset(oobbuf, 0xff, sizeof(oobbuf));
	/* Calculate ECC for each subpage of 256 bytes */
/*
 	memset(oobbuf, 0xff, sizeof(oobbuf));
	for (eccpoi = 0, i = 0; i < args->pagesize; i += 256, eccpoi += 3) {
		int j;
		nand_calculate_ecc(&buf[i], ecc_code);
		for (j = 0; j < 3; j++)
			oobbuf[args->nand_oob->eccpos[eccpoi + j]] = ecc_code[j];
	}
*/

	/* write data */
//	*written += fwrite(buf, 1, args->pagesize, fp_data);

	/* either separate oob or interleave with data */
	// if (fp_oob) {
		// i = fwrite(oobbuf, 1, args->oobsize, fp_oob);
		// if (ferror(fp_oob)) {
			// err_msg("IO error\n");
			// return -EIO;
		// }
	// }
	// else {
		// i = fwrite(oobbuf, 1, args->oobsize, fp_data);
		// if (ferror(fp_data)) {
			// err_msg("IO error\n");
			// return -EIO;
		// }
	// }

	return 0;
}

static int
process_page_bch16(struct args *args, uint8_t *buf, FILE *fp_data, FILE *fp_oob,
	     size_t *written)
{
	int eccpoi;
	int i, j, k, l, m, n, p, in_count, in_codeword;
	uint8_t oobbuf[args->oobsize];
	uint8_t ecc_code[28] = { 0, }; /* temp */
	int empty, start_pos;
	
	

	
	/* convert data to data[] in binary format, 512 * 8 = 4096 */
	in_count = 0;
	in_codeword = 0;
	empty = 1;
	memset(oobbuf, 0xff, sizeof(oobbuf));
	
	for (i=0; i < args->pagesize; i++){
		if (buf[i] != 255){
			empty = 0;
			break;
		}
	}
	if (!empty){		
		fprintf(stderr,"%d page read...\n", pages);
		pages++;
		
		/* encode every 1024 bytes and generate 28 bytes ecc		*/
		/* so ecc starting position should be  						*/
		/* start_pos = args->oobsize - (28 * args->pagesize / 1024) */
		/* write flag position = start_pos - 1						*/
		/* 															*/
		
		start_pos = args->oobsize - (28 * args->pagesize / 1024);
//		fprintf(stderr,"ecc starting from position start_pos %d\n", start_pos);
		
		for (eccpoi = start_pos, i = 0; i < args->pagesize; i += 1024, eccpoi += 28) {
			in_count = 0;
			in_codeword = 0;
			for (p = 0; p < 1024; p += 1){
				for(j = 7; j >= 0; j--){
					if (((int)pow(2,j)) & (buf[p + i]))
						data[in_count] = 1;
					else
						data[in_count] = 0;
					in_count++;
				}
			}
			
//			fprintf(stderr,"data in: \n");
//			print_hex_low(1024*8, data, stderr);
			parallel_encode_bch();
//			fprintf(stderr,"ecc out: \n");
//			print_hex_low(28*8, bb, stderr); 
			
			
			l = ceil((double)rr / 8);
//			fprintf(stderr,"l , rr = %d, %d\n", l, rr);
			for (j = 0; j < l; j++) 
			{	m = 0;
				for(n = 7; n >= 0; n--){
					m = m + (int)bb[j * 8 + n] * (int)pow(2, n);
				}
				oobbuf[eccpoi + j] = m;
//				fprintf(stderr,"eccpoi, j, m = %d, %d, %c\n", eccpoi, j, inttohex(m));
			}		
		}
		/* one page process complete */
		oobbuf[start_pos - 1] = 0;
	}
	/* write data */
	*written += fwrite(buf, 1, args->pagesize, fp_data);

	/* write oob interleave with data */
	i = fwrite(oobbuf, 1, args->oobsize, fp_data);

	/* clear the buff for next page */
	memset(oobbuf, 0xff, sizeof(oobbuf));
	
	return 0;
}

void generate_gf()   
/* Generate GF(2**mm) from the primitive polynomial p(X) in p[0]..p[mm]  
   The lookup table looks like:    
   index -> polynomial form:   alpha_to[ ] contains j = alpha**i;  
   polynomial form -> index form:  index_of[j = alpha**i] = i  
   alpha_to[1] = 2 is the primitive element of GF(2**mm)  
 */   
{   int i;   
    int mask ;  // Register states   
       
    // Primitive polynomials   
    for (i = 1; i < mm; i++)   
        p[i] = 0;   
    p[0] = p[mm] = 1;   
    if (mm == 2)        p[1] = 1;   
    else if (mm == 3)   p[1] = 1;   
    else if (mm == 4)   p[1] = 1;   
    else if (mm == 5)   p[2] = 1;   
    else if (mm == 6)   p[1] = 1;   
    else if (mm == 7)   p[1] = 1;   
    else if (mm == 8)   p[4] = p[5] = p[6] = 1;   
    else if (mm == 9)   p[4] = 1;   
    else if (mm == 10)  p[3] = 1;   
    else if (mm == 11)  p[2] = 1;   
    else if (mm == 12)  p[3] = p[4] = p[7] = 1;   
    else if (mm == 13)  p[1] = p[2] = p[3] = p[5] = p[7] = p[8] = p[10] = 1;    // 25AF   
    // else if (mm == 13)   p[1] = p[3] = p[4] = 1;   
    else if (mm == 14)  p[2] = p[4] = p[6] = p[7] = p[8] = 1;   // 41D5   
    // else if (mm == 14)   p[1] = p[11] = p[12] = 1;   
    else if (mm == 15)  p[1] = 1;   
    else if (mm == 16)  p[2] = p[3] = p[5] = 1;   
    else if (mm == 17)  p[3] = 1;   
    else if (mm == 18)  p[7] = 1;   
    else if (mm == 19)  p[1] = p[5] = p[6] = 1;   
    else if (mm == 20)  p[3] = 1;   
       
    if (Verbose)   
    {   fprintf(stderr, "# The Galois field is GF(2**%d);\n\n", mm);   
        fprintf(stderr, "# The primitive polynomial is: p(x) = ");   
        for (i = 0; i <= mm; i++)    
        {   fprintf(stderr, " %d", p[i]);   
        }   
        fprintf(stderr, "\n\n");   
    }   
       
    // Galois field implementation with shift registers   
    // Ref: L&C, Chapter 6.7, pp. 217   
    mask = 1 ;   
    alpha_to[mm] = 0 ;   
    for (i = 0; i < mm; i++)   
    {   alpha_to[i] = mask ;   
        index_of[alpha_to[i]] = i ;   
        if (p[i] != 0)   
            alpha_to[mm] ^= mask ;   
           
        mask <<= 1 ;   
    }   
       
    index_of[alpha_to[mm]] = mm ;   
    mask >>= 1 ;   
    for (i = mm + 1; i < nn; i++)   
    {   if (alpha_to[i-1] >= mask)   
            alpha_to[i] = alpha_to[mm] ^ ((alpha_to[i-1] ^ mask) << 1) ;   
        else alpha_to[i] = alpha_to[i-1] << 1 ;   
           
        index_of[alpha_to[i]] = i ;   
    }   
    index_of[0] = -1 ;   
       
    // Print out the Galois Field   
    if (Verbose)   
    {   fprintf(stderr, "# Look-up tables for GF(2**%2d)\n", mm) ;   
        fprintf(stderr, "  i   alpha_to[i]  index_of[i]\n") ;   
        for (i=0; i<=nn; i++)   
            fprintf(stderr, "%3d      %3d          %3d\n", i, alpha_to[i], index_of[i]) ;   
        fprintf(stderr, "\n") ;   
    }   
}   


void gen_poly()   
/* Compute generator polynomial of the tt-error correcting Binary BCH code   
 * g(x) = LCM{M_1(x), M_2(x), ..., M_2t(x)},  
 * where M_i(x) is the minimal polynomial of alpha^i by cyclotomic cosets  
 */   
{   int gen_roots[nn + 1], gen_roots_true[nn + 1] ;     // Roots of generator polynomial   
    int i, j, iii, jjj, Temp ;   
           
    // Initialization of gen_roots   
    for (i = 0; i <= nn; i++)    
    {   gen_roots_true[i] = 0;   
        gen_roots[i] = 0;   
    }   
   
    // Cyclotomic cosets of gen_roots   
    for (i = 1; i <= 2*tt ; i++)   
    {   for (j = 0; j < mm; j++)    
        {   Temp = ((int)pow(2, j) * i) % nn;   
            gen_roots_true[Temp] = 1;   
        }   
    }   
       
    rr = 0;     // Count the number of parity check bits   
    for (i = 0; i < nn; i++)    
    {   if (gen_roots_true[i] == 1)    
        {   rr++;   
            gen_roots[rr] = i;   
        }   
    }   
    kk = nn - rr;   
       
    // Compute generator polynomial based on its roots   
    gg[0] = 2 ; // g(x) = (X + alpha) initially   
    gg[1] = 1 ;   
    for (i = 2; i <= rr; i++)   
    {   gg[i] = 1 ;   
        for (j = i - 1; j > 0; j--)   
        if (gg[j] != 0)     
            gg[j] = gg[j-1]^ alpha_to[(index_of[gg[j]] + index_of[alpha_to[gen_roots[i]]]) % nn] ;   
        else    
            gg[j] = gg[j-1] ;   
        gg[0] = alpha_to[(index_of[gg[0]] + index_of[alpha_to[gen_roots[i]]]) % nn] ;   
    }   
       
    if (Verbose)   
    {   fprintf(stderr, "# The Generator Polynomial is:\n") ;   
        for (i=0; i <= rr; i++)     
            fprintf(stderr, " %d", gg[i]) ;   
        fprintf(stderr, "\n\n") ;   
    }   
       
    // for parallel encoding and syndrome computation   
    // Max parallalism is rr   
    if (Parallel > rr)   
        Parallel = rr ;   
       
    // Construct parallel lookahead matrix T_g, and T_g**r from gg(x)   
    // Ref: Parallel CRC, Shieh, 2001   
    for (i = 0; i < rr; i++)   
    {   for (j = 0; j < rr; j++)   
            T_G[i][j] = 0;   
    }   
       
    for (i = 1; i < rr; i++)   
        T_G[i][i-1] = 1 ;   
   
    for (i = 0; i < rr; i++)   
        T_G[i][rr - 1] = gg[i] ;   
       
    for (i = 0; i < rr; i++)   
    {   for (j = 0; j < rr; j++)   
            T_G_R[i][j] = T_G[i][j];   
    }   
       
    // Compute T_G**R Matrix   
    for (iii = 1; iii < Parallel; iii++)   
    {   for (i = 0; i < rr; i++)   
        {   for (j = 0; j < rr; j++)   
            {   Temp = 0;   
                for (jjj = 0; jjj < rr; jjj++)   
                    Temp = Temp ^ T_G_R[i][jjj] * T_G[jjj][j];   
                   
                T_G_R_Temp[i][j] = Temp;   
            }   
        }   
           
        for (i = 0; i < rr; i++)   
        {   for (j = 0; j < rr; j++)   
                T_G_R[i][j] = T_G_R_Temp[i][j];   
        }   
    }   
}

int main (int argc, char** argv)
{
	int rc = -1;
	int res = 0;
	size_t written = 0, read;
	struct args args = {
		.action	  = ACT_NORMAL,
		.pagesize = PAGESIZE,
		.padding  = PADDING,
		.fp_in	  = NULL,
		.file_out_data = NULL,
		.file_out_oob = NULL,
		.nand_oob = &ibm_nand_oob_64,
	};

	FILE* fp_out_data = stdout;
	FILE* fp_out_oob = NULL;

	parse_opt(argc, argv, &args);

	uint8_t* buf = calloc(1, BUFSIZE);
	if (!buf) {
		err_quit("Cannot allocate page buffer.\n");
	}

	if (!args.fp_in) {
		err_msg("No input image specified!\n");
		goto err;
	}

	if (args.file_out_data) {
		fp_out_data = fopen(args.file_out_data, "wb");
		if (fp_out_data == NULL) {
			err_sys("Cannot open file %s for output\n",
					args.file_out_data);
			goto err;
		}
	}

	if (args.file_out_oob) {
		fp_out_oob = fopen(args.file_out_oob, "wb");
		if (fp_out_oob == NULL) {
			err_sys("Cannot open file %s for output\n",
					args.file_out_oob);
			goto err;
		}
	}

	while(1) {
		/* read one page of data to buff and process at a time */
		read = fread(buf, 1, args.pagesize, args.fp_in);
		if (feof(args.fp_in) && read == 0)
			break;
		if (read < args.pagesize) {
			err_msg("Image not page aligned\n");
			goto err;
		}
		if (ferror(args.fp_in)) {
			err_msg("Read error\n");
			goto err;
		}
		if (strcmp(ecc_layout, "BCH8") == 0){
			/* Set BCH8 parameters */
			/* BCH code parameters */
			mm = 13;
			nn = 8191;
			tt = 8;
			
			/* Shortened BCH code */
			nn_shorten = nn;
			kk_shorten = 4096;
			
			Parallel = 8;			// Parallel processing
			Verbose = 0;			// Mode indicator
				
			// generate the Galois Field GF(2**mm)
			generate_gf() ;
		
			// Compute the generator polynomial and lookahead matrix for BCH code
			gen_poly() ;
			
			res = process_page_bch8(&args, buf, fp_out_data, fp_out_oob,
				   &written);
		}
		else if(strcmp(ecc_layout, "BCH16") == 0){
			/* Set BCH8 parameters */
			/* BCH code parameters */
			mm = 14;
			nn = 8192;
			tt = 16;
	
			/* Shortened BCH code */
			nn = (int)pow(2, mm) - 1 ;   
			nn_shorten = nn;
			kk_shorten = 8192;
			
			Parallel = 8;			// Parallel processing
			Verbose = 0;			// Mode indicator
			
			// generate the Galois Field GF(2**mm)
			generate_gf() ;
		
			// Compute the generator polynomial and lookahead matrix for BCH code
			gen_poly() ;
			
			res = process_page_bch16(&args, buf, fp_out_data, fp_out_oob,
				   &written);
		}
		else{
			res = process_page(&args, buf, fp_out_data, fp_out_oob,
				   &written);
		}
		
		if (res != 0)
			goto err;
	}

	while (written < args.padding) {
		memset(buf, 0xff, args.pagesize);
		res = process_page(&args, buf, fp_out_data, fp_out_oob,
				   &written);
		if (res != 0)
			goto err;
	}

	rc = 0;
err:
	free(buf);

	if (args.fp_in)
		fclose(args.fp_in);

	if (fp_out_oob)
		fclose(fp_out_oob);

	if (fp_out_data && fp_out_data != stdout)
		fclose(fp_out_data);

	if (rc != 0) {
		err_msg("Error during conversion. rc: %d\n", rc);
		if (args.file_out_data)
			remove(args.file_out_data);
		if (args.file_out_oob)
			remove(args.file_out_oob);
	}
	return rc;
}
