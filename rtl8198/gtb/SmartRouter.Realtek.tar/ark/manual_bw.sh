#!/bin/sh

help() {
    echo "Usage: manual_bw.sh <upstream> <downstream>"
    echo "  upstream: the upstream bandwidth (Mbps)"
    echo "  downstream: the downstream bandwidth (Mbps)"
}

if [ $# -ne 2 ];then
    help
    exit 0
fi

bw_Mb_up=$1
bw_Mb_down=$2

if [ ! -f /proc/ark/ctrl ];then
    help
    exit 0
fi
if [ ${bw_Mb_up} -le 0 ];then
    help
    exit 0
fi
if [ ${bw_Mb_down} -le 0 ];then
    help
    exit 0
fi

echo "env bandwidth ${bw_Mb_up}Mb ${bw_Mb_down}Mb" > /proc/ark/ctrl
echo "env BTCW 3 ${bw_Mb_up}Mb ${bw_Mb_down}Mb" > /proc/ark/ctrl
echo "env BTCW 4 ${bw_Mb_up}Mb ${bw_Mb_down}Mb" > /proc/ark/ctrl
echo "env R5S2 80 100 80 100" > /proc/ark/ctrl
echo "env UDDP 15 5 95 15 5 95" > /proc/ark/ctrl
echo "env V36 20 5" > /proc/ark/ctrl
echo "env ELVS 0 70 4 1 2 1 70 4 1 2 1" > /proc/ark/ctrl
echo "env ELVS 1 60 5 2 4 2 60 5 2 4 2" > /proc/ark/ctrl
