#!/bin/sh

if [ ! -f /proc/ark/ctrl ];then
    exit 0
fi

echo "env bandwidth 0Mb 0Mb" > /proc/ark/ctrl
echo "env BTCW 3 1023Mb 1023Mb" > /proc/ark/ctrl
echo "env BTCW 4 1023Mb 1023Mb" > /proc/ark/ctrl
echo "env R5S2 90 100 90 100" > /proc/ark/ctrl
echo "env UDDP 15 5 90 15 5 90" > /proc/ark/ctrl
echo "env V36 20 5" > /proc/ark/ctrl
echo "env ELVS 0 80 5 1 2 1 85 5 1 2 1" > /proc/ark/ctrl
echo "env ELVS 1 65 5 2 5 2 70 5 2 4 2" > /proc/ark/ctrl
