teraterm scripts for G3 testing via IROS or APP-CLI
user can entery iros commands in iros-cmd.txt, then run iros-cmd.ttl to execute the entered commands
for app-cli, use reg_ops.ttl and reg_ops.txt

5/10/16 enhancement
Three files needed to define a test case. Use example-xxx as template
1. example-script.ttl: this is the main script file. Just change the two specification file names at the top of file. Do not change other stuff.
2. example-cmds.txt: this file contains all the register set/get commands with CSR symbol names
3. example-defines.txt: this file contains all the CSR #defines that maps CSR symbol names to CSR addresses
