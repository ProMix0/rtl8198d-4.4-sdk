#include <stdio.h>
#include <xtables.h>
#include <linux/netfilter/xt_flowlblrange.h>

enum {
	O_FLOWLABEL_RANGE = 0,
};

static void flowlbl_range_help(void)
{
	printf(
"flowlbl match options\n"
"[!] --flowlbl-range value1[:value2]		Match IPv6 Flow Label against value or range\n"
"                                of values (inclusive)\n");
}

static const struct xt_option_entry flowlbl_range_opts[] = {
	{.name = "flowlbl-range", .id = O_FLOWLABEL_RANGE, .type = XTTYPE_UINT32RC,
	 .flags = XTOPT_MAND | XTOPT_INVERT},
	XTOPT_TABLEEND,
};

static void flowlbl_range_parse(struct xt_option_call *cb)
{
	struct xt_flowlbl_range_info *info = cb->data;

	xtables_option_parse(cb);

	if (cb->val.u32_range[0] > XT_FLOWLABEL_MAX)
		xtables_error(PARAMETER_PROBLEM,
			   "Flow Label `%d` out of range\n", cb->val.u32_range[0]);
	
	info->flowlbl_min = cb->val.u32_range[0];
	info->flowlbl_max = cb->val.u32_range[0];
	if (cb->nvals >= 2) {
		if (cb->val.u32_range[1] > XT_FLOWLABEL_MAX)
			xtables_error(PARAMETER_PROBLEM,
			   "Flow Label `%d` out of range\n", cb->val.u32_range[1]);
		info->flowlbl_max = cb->val.u32_range[1];
	}
	if (cb->invert)
		info->invert = 1;
}

static void
flowlbl_range_print(const void *ip, const struct xt_entry_match *match, int numeric)
{
	const struct xt_flowlbl_range_info *dinfo = (const struct xt_flowlbl_range_info *)match->data;
		
	printf(" Flow Label range %s0x%02x-0x%02x", dinfo->invert ? "!" : "", dinfo->flowlbl_min, dinfo->flowlbl_max);
}

static void flowlbl_range_save(const void *ip, const struct xt_entry_match *match)
{
	const struct xt_flowlbl_range_info *dinfo = (const struct xt_flowlbl_range_info *)match->data;

	printf("%s --flowlbl-range 0x%02x-0x%02x", dinfo->invert ? "! " : "", dinfo->flowlbl_min, dinfo->flowlbl_max);
}

static struct xtables_match flowlbl_range_match = {
	.family		= NFPROTO_IPV6,
	.name 		= "flowlblrange",
	.version 	= XTABLES_VERSION,
	.size 		= XT_ALIGN(sizeof(struct xt_flowlbl_range_info)),
	.userspacesize	= XT_ALIGN(sizeof(struct xt_flowlbl_range_info)),
	.help		= flowlbl_range_help,
	.print		= flowlbl_range_print,
	.save		= flowlbl_range_save,
	.x6_parse	= flowlbl_range_parse,
	.x6_options	= flowlbl_range_opts,
};

void _init(void)
{
	xtables_register_match(&flowlbl_range_match);
}
