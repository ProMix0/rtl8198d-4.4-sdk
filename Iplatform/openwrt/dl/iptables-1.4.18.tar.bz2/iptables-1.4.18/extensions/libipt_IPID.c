/* Shared library add-on to iptables for the IPID target
 * This program is distributed under the terms of GNU GPL
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <getopt.h>
#include <xtables.h>

#include <linux/netfilter_ipv4/ip_tables.h>
#include <linux/ipt_IPID.h>

#define IPT_IPID_USED	1

static void IPID_help(void) 
{
	printf(
		"IPID target options\n"
		"--ipid-pace value\n"
		"--ipid-chaotic value\n");
#ifdef CONFIG_IPV6_MAPE_IPID_ADJUST
	printf("--ipid-mape\n");
#endif

}

static int IPID_parse (int c, char **argv, int invert, unsigned int *flags,
			const void *entry, struct xt_entry_target **target)

{
	struct ipt_IPID_info *info = (struct ipt_IPID_info *) (*target)->data;
	unsigned int value;

	if (*flags & IPT_IPID_USED) {
		xtables_error(PARAMETER_PROBLEM, 
				"Can't specify IPID option twice");
	}
#ifdef CONFIG_IPV6_MAPE_IPID_ADJUST
	if (c != '3') //--ipid-mape
#endif
	{
		if (!optarg)
			xtables_error(PARAMETER_PROBLEM,
					"IPID: You must specify a value");
	/*
		if (xtables_check_inverse(optarg,&invert,NULL,0, argv))
			xtables_error(PARAMETER_PROBLEM,
					"IPID: unexpected '!'");
	*/
		if(!xtables_strtoui(optarg, NULL, &value, 0, 65535))
			xtables_error(PARAMETER_PROBLEM,
					"IPID: Expected value between 0 and 65535");
	}
	switch (c) {
		case '1':
			info->mode = IP_IPID_PACE;
			info->ipid = value;
			break;
		case '2':
			info->mode = IP_IPID_CHAOTIC;
			break;			
	#ifdef CONFIG_IPV6_MAPE_IPID_ADJUST
		case '3':
			info->mode = IP_IPID_MAPE;
			break;
	#endif
	}
	*flags |= IPT_IPID_USED;

	return 1;
}

static void IPID_check(unsigned int flags)
{
	if (!(flags & IPT_IPID_USED))
		xtables_error(PARAMETER_PROBLEM,
				"IPID: You must specify an action");
}

static void IPID_save (const void *ip, const struct xt_entry_target *target)
{
	const struct ipt_IPID_info *info = 
		(struct ipt_IPID_info *) target->data;
	switch(info->mode){
		case IP_IPID_PACE:
			printf(" --ipid-pace %u",info->ipid);
			break;
		case IP_IPID_CHAOTIC:
			printf(" --ipid-chaotic 0");
			break;			
	#ifdef CONFIG_IPV6_MAPE_IPID_ADJUST
		case IP_IPID_MAPE:
			printf(" --ipid-mape");
			break;
	#endif
	}

}

static void IPID_print (const void *ip, const struct xt_entry_target *target,int numeric) 
{
	const struct ipt_IPID_info *info =
		(struct ipt_IPID_info *) target->data;

	printf("IPID ");
	switch(info->mode){	
		case IP_IPID_PACE:
			printf("pace is %u ", info->ipid);
			break;
		case IP_IPID_CHAOTIC:
			printf("chaotic");
			break;
	#ifdef CONFIG_IPV6_MAPE_IPID_ADJUST
		case IP_IPID_MAPE:
			printf("mape portset");
			break;
	#endif
		default:
			printf("chaotic");
	}
}

static struct option IPID_opts[] = {
	{ "ipid-pace",	1,	NULL, '1'	},
	{ "ipid-chaotic",1,	NULL, '2'	},
#ifdef CONFIG_IPV6_MAPE_IPID_ADJUST
	{ "ipid-mape", 0,	NULL, '3'	},
#endif
	{ .name=NULL	}	
};

static struct xtables_target ipid_tg_reg = {
	.name		= "IPID",
	.version	= XTABLES_VERSION,
	.family         = NFPROTO_IPV4,
	.size		= XT_ALIGN(sizeof(struct ipt_IPID_info)),
	.userspacesize	= XT_ALIGN(sizeof(struct ipt_IPID_info)),
	.help		= IPID_help,
	.parse		= IPID_parse,
	.final_check	= IPID_check,
	.print		= IPID_print,
	.save		= IPID_save,
	.extra_opts	= IPID_opts, 
};

void _init(void)
{
	xtables_register_target(&ipid_tg_reg);
}
